<?php include("template/cabecera.php");?>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="https://www.w3schools.com/bootstrap4/img_avatar1.png" alt=""></img>
    
<div class="card-body">
        <h4 class="card-title">COLORES </h4>
        <a name="" id="" class="btn btn-primary" href="#" role="button">ver mas</a>
</div>

</div>

</div>





<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="https://www.w3schools.com/bootstrap4/img_avatar1.png" alt="">
    
<div class="card-body">
        <h4 class="card-title">MEDIDAS </h4>
        <a name="" id="" class="btn btn-primary" href="#" role="button">ver mas</a>
</div>

</div>

</div>





<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="https://www.w3schools.com/bootstrap4/img_avatar1.png" alt="">
    
<div class="card-body">
        <h4 class="card-title">cockteles </h4>
        <a name="" id="" class="btn btn-primary" href="#" role="button">ver mas</a>
</div>

</div>

</div>



<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="https://www.w3schools.com/bootstrap4/img_avatar1.png" alt="">
    
<div class="card-body">
        <h4 class="card-title">TEXTURAS</h4>
        <a name="" id="" class="btn btn-primary" href="#" role="button">ver mas</a>
</div>

</div>

</div>







<?php include("template/pie.php"); ?>